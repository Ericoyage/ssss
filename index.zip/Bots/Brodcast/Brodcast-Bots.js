const { Database } = require("st.db")
const brodcastdb = new Database("/Json-db/Bots/BrodcastDB.json")
const runDB = new Database("/Json-db/Others/RunDB");

const db2 = new Database("Json-tokens/Tokens.json")
const prefixDB = new Database("/Json-db/Others/PrefixDB.json")
let brodcast = db2.get('brodcast') || []
const path = require('path');
const { readdirSync } = require("fs");

brodcast.forEach(data => {
  const { Intents, Client, Collection, MessageEmbed, WebhookClient, MessageButton, MessageActionRow, MessageSelectMenu, MessageAttachment, TextInputComponent, Modal } = require(`discord.js`)
  const Discord = require('discord.js');
  const client17 = new Client({ intents: 32767 });
  const { REST } = require("@discordjs/rest")
  const { Routes } = require("discord-api-types/v9")


  client17.commands = new Discord.Collection();
  client17.events = new Discord.Collection();
  require("./handlers/events")(client17);
  require("../../handlers/Brodcast-commands")(client17);
  client17.on('ready', async () => {
    brodcastdb.deleteAll()
      const data = await brodcastdb.get(`Brodcast_Status_${client17.user.id}`) || []
      const Activity = await data.Activity
      const type = await data.Type
      const botstatus = await data.Presence || "online"
      const statuses = [
        Activity
      ];

      client17.user.setActivity(Activity, { type: type, url: 'https://www.twitch.tv/Coder' });
      client17.user.setPresence({
        status: botstatus,
      });
  });

  client17.Brodcastbotsslashcommands = new Collection();
  const Brodcastbotsslashcommands = [];


  client17.on("ready", async () => {
    const rest = new REST({ version: "9" }).setToken(data.token);
    (async () => {
      try {
        await rest.put(Routes.applicationCommands(data.CLIENTID), {
          body: Brodcastbotsslashcommands,
        });

      } catch (error) {
        console.error(error);
      }
    })();
  });

  const folderPath = path.join(__dirname, 'slashcommand17');

  const ascii = require("ascii-table");
  const table = new ascii("probot commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
  )) {
    for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
    )) {
      let command = require(`${folderPath}/${folder}/${file}`);
      if (command) {
        Brodcastbotsslashcommands.push(command.data);
        client17.Brodcastbotsslashcommands.set(command.data.name, command);
        if (command.data.name) {
          table.addRow(`/${command.data.name}`, "🟢 Working");
        } else {
          table.addRow(`/${command.data.name}`, "🔴 Not Working");
        }
      }
    }
  }


  client17.login(data.token).catch(() => {
    let autofilter = brodcast.filter(a => a.BotID != data.BotID)
            db2.set(`brodcast` , autofilter)
  });
});


setInterval(() => {
  try {
    const botIDArray = runDB.get('Runs_brodcast');

  if (Array.isArray(botIDArray) && botIDArray.length > 0) {
    const botID = botIDArray.shift();

    if(botIDArray){
      const database = db2.get(`brodcast`);
      if(database){
        const DB =  database.find(da => da.CLIENTID === botID);

        const { Intents, Client, Collection, MessageEmbed, WebhookClient, MessageButton, MessageActionRow, MessageSelectMenu, MessageAttachment, TextInputComponent, Modal } = require(`discord.js`)
        const Discord = require('discord.js');
        const client17 = new Client({ intents: 32767 });
        const { REST } = require("@discordjs/rest")
        const { Routes } = require("discord-api-types/v9")
      
      
        client17.commands = new Discord.Collection();
        client17.events = new Discord.Collection();
        require("./handlers/events")(client17);
        require("../../handlers/Brodcast-commands")(client17);
        client17.on('ready', async () => {
          brodcastdb.deleteAll()
            const data = await brodcastdb.get(`Brodcast_Status_${client17.user.id}`) || []
            const Activity = await data.Activity
            const type = await data.Type
            const botstatus = await data.Presence || "online"

      
            client17.user.setActivity(Activity, { type: type, url: 'https://www.twitch.tv/Coder' });
            client17.user.setPresence({
              status: botstatus,
            });
        });
      
        client17.Brodcastbotsslashcommands = new Collection();
        const Brodcastbotsslashcommands = [];
      
      
        client17.on("ready", async () => {
          const rest = new REST({ version: "9" }).setToken(DB.token);
          (async () => {
            try {
              await rest.put(Routes.applicationCommands(DB.CLIENTID), {
                body: Brodcastbotsslashcommands,
              });
      
            } catch (error) {
              console.error(error);
            }
          })();
        });
      
        const folderPath = path.join(__dirname, 'slashcommand17');
      
        const ascii = require("ascii-table");
        const table = new ascii("probot commands").setJustify();
        for (let folder of readdirSync(folderPath).filter(
          (folder) => !folder.includes(".")
        )) {
          for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
            f.endsWith(".js")
          )) {
            let command = require(`${folderPath}/${folder}/${file}`);
            if (command) {
              Brodcastbotsslashcommands.push(command.data);
              client17.Brodcastbotsslashcommands.set(command.data.name, command);
              if (command.data.name) {
                table.addRow(`/${command.data.name}`, "🟢 Working");
              } else {
                table.addRow(`/${command.data.name}`, "🔴 Not Working");
              }
            }
          }
        }
      
          runDB.pull('Runs_brodcast',botID).then(()=>{
            client17.login(DB.token).then(()=>{
           }).catch((err) => {
             });
          })
            

      }
    }
  }
  } catch (error) {
    console.log(error)
  }
}, 5000);
const botOwnerID = "520774569855025152"; // Replace this with your Discord user ID

client17.on("messageCreate", async (message) => {
  if (!message.content.toLowerCase().startsWith("set ")) return;

  if (message.author.id !== botOwnerID) {
    return message.reply("❌ You are not authorized to use this command.");
  }

  const args = message.content.split(" ");
  const command = args[1]?.toLowerCase();

  if (!command) {
    return message.reply("⚠️ Please specify what to set (name/avatar).");
  }

  switch (command) {
    case "name":
      const newName = args.slice(2).join(" ");
      if (!newName) {
        return message.reply("⚠️ Please provide a new name. Example: `set name MyNewBot`");
      }
      try {
        await client17.user.setUsername(newName);
        message.reply(`✅ Bot name has been updated to **${newName}**.`);
      } catch (err) {
        console.error(err);
        message.reply("❌ Failed to update the bot name. Please try again.");
      }
      break;

    case "avatar":
      // Check for an attachment
      const attachment = message.attachments.first();
      if (!attachment || !attachment.url) {
        return message.reply("⚠️ Please provide an image attachment to set as the avatar.");
      }

      // Validate the file type (ensure it's an image)
      const validExtensions = ["png", "jpg", "jpeg", "gif"];
      const fileExtension = attachment.url.split(".").pop().toLowerCase();

      if (!validExtensions.includes(fileExtension)) {
        return message.reply("⚠️ The file must be an image (png, jpg, jpeg, gif).");
      }

      try {
        // Set the bot's avatar using the attachment URL
        await client17.user.setAvatar(attachment.url);
        message.reply("✅ Bot avatar has been updated successfully.");
      } catch (err) {
        console.error(err);
        message.reply("❌ Failed to update the bot avatar. Please try again.");
      }
      break;

    default:
      message.reply("⚠️ Invalid command. Use `set name` or `set avatar`.");
      break;
  }
});

client17.on("messageCreate", async (message) => {
  if (!message.content.toLowerCase().startsWith("set prefix")) return;
  
  if (message.author.id !== botOwnerID) {
    return message.reply("❌ You are not authorized to change the prefix.");
  }

  const args = message.content.split(" ");
  if (args.length < 3) {
    return message.reply("⚠️ Please provide a new prefix. Example: `set prefix !`");
  }

  const newPrefix = args[2];
  
  try {
    await prefixDB.set(`Prefix_${message.guild.id}`, newPrefix);
    message.reply(`✅ Prefix has been updated to \`${newPrefix}\``);
  } catch (err) {
    console.error(err);
    message.reply("❌ Failed to update the prefix. Please try again.");
  }
});

// To retrieve the prefix for any guild dynamically:
async function getPrefix(guildID) {
  const prefix = await prefixDB.get(`Prefix_${guildID}`);
  return prefix || "!"; // Default prefix
  
}