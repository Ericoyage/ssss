const Discord = require('discord.js');
const { MessageEmbed, MessageActionRow, MessageSelectMenu } = require('discord.js');
const { Database } = require("st.db");
const prefixDB = new Database("/Json-db/Others/PrefixDB.json");

module.exports = {
  name: "help",
  aliases: [""],
  description: "",
  usage: [""],
  botPermission: [""],
  authorPermission: [""],
  cooldowns: [10],
  ownerOnly: false,
  run: async (client, message, args, config) => {
    const prefix = prefixDB.get(`Prefix_${client.user.id}_system`) || "!";

    const embeds = [
      new MessageEmbed()
        .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true }))
        .setTimestamp()
        .setColor('#7289DA')
        .setTitle('📜 الأوامر العامة')
        .setFooter(`تم الطلب من ${message.author.username}`, message.author.displayAvatarURL({ dynamic: true }))
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
          { name: `${prefix}**avatar**`, value: 'عرض صورة شخص ما', inline: false },
          { name: `${prefix}**banner**`, value: 'عرض راية شخص ما', inline: false },
          { name: `${prefix}**roles**`, value: 'عرض جميع الأدوار في السيرفر', inline: false },
          { name: `${prefix}**server**`, value: 'عرض بعض المعلومات عن السيرفر', inline: false },
          { name: `${prefix}**user**`, value: 'عرض بعض المعلومات عن مستخدم معين', inline: false }
        ),

      new MessageEmbed()
        .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true }))
        .setTimestamp()
        .setColor('#43B581')
        .setTitle('⚙️ الأوامر الإدارية')
        .setFooter(`تم الطلب من ${message.author.username}`, message.author.displayAvatarURL({ dynamic: true }))
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
          { name: `${prefix}**ban**`, value: 'باند عضو من السيرفر', inline: true },
          { name: `${prefix}**unban**`, value: 'رفع الباند عن عضو من السيرفر', inline: true },
          { name: `${prefix}**unban-all**`, value: 'رفع الباند عن جميع المستخدمين المحظورين من السيرفر', inline: true },
          { name: `${prefix}**kick**`, value: 'طرد عضو من السيرفر', inline: true },
          { name: `${prefix}**clear**`, value: 'مسح الرسائل في الشات بحد أقصى 100 رسالة', inline: true },
          { name: `${prefix}**lock**`, value: 'قفل الشات للجميع', inline: true },
          { name: `${prefix}**unlock**`, value: 'فتح الشات للجميع', inline: true },
          { name: `${prefix}**mute**`, value: 'كتم صوت عضو معين في السيرفر', inline: true },
          { name: `${prefix}**unmute**`, value: 'رفع الكتم عن عضو معين في السيرفر', inline: true }
        ),

      new MessageEmbed()
        .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true }))
        .setTimestamp()
        .setColor('#F47C48')
        .setTitle('⚙️ أوامر إعدادات البوت')
        .setFooter(`تم الطلب من ${message.author.username}`, message.author.displayAvatarURL({ dynamic: true }))
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
          { name: `${prefix}**set-owner**`, value: 'تغيير مالك البوت', inline: false },
          { name: `${prefix}**set-prefix**`, value: 'تغيير بادئة البوت', inline: false },
          { name: `${prefix}**set-avatar**`, value: 'تغيير صورة البوت', inline: false },
          { name: `${prefix}**set-name**`, value: 'تغيير اسم البوت', inline: false }
        )
    ];

    const selectMenuOptions = embeds.map((embed, index) => ({
      label: embed.title,
      value: index.toString(),
      description: `لعرض أوامر ${embed.title}`,
      emoji: index === 0 ? '📜' : index === 1 ? '⚙️' : '🔧'
    }));

    const selectMenu = new MessageSelectMenu()
      .setCustomId('help_select')
      .setPlaceholder('اختر صفحة...')
      .addOptions(selectMenuOptions);

    const actionRow = new MessageActionRow().addComponents(selectMenu);

    const initialEmbed = embeds[0];

    const helpMessage = await message.reply({
      embeds: [initialEmbed],
      components: [actionRow]
    });

    const filter = (interaction) =>
      interaction.isSelectMenu() && interaction.user.id === message.author.id;

    const collector = helpMessage.createMessageComponentCollector({
      filter,
      time: 60000
    });

    collector.on('collect', (interaction) => {
      const selectedPageIndex = parseInt(interaction.values[0]);
      const selectedEmbed = embeds[selectedPageIndex];
      interaction.update({
        embeds: [selectedEmbed]
      });
    });

    collector.on('end', () => {
      helpMessage.edit({
        components: []
      });
    });
  }
};
