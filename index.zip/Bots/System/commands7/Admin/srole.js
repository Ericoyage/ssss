const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
  name: "myrole",
  aliases: ["تحكم_بدوري", "دوري"],
  description: "Manage your special role",
  usage: ["!myrole"],
  botPermission: ["MANAGE_ROLES"],
  authorPermission: ["MANAGE_ROLES"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args, config) => {
    const member = message.member;
    const role = message.guild.roles.cache.find(r => r.name.includes(member.user.username) && r.members.has(member.id));

    if (!role) return message.reply({ content: `❌ **ليس لديك دور خاص لإدارته!**` });

    const embed = new MessageEmbed()
      .setTitle(`إدارة دور ${role.name}`)
      .setDescription("اختر أحد الخيارات أدناه لإدارة دورك.")
      .setColor(role.color)
      .setFooter(`Requested by ${member.user.username}`, member.user.displayAvatarURL({ dynamic: true }));

    const row = new MessageActionRow().addComponents(
      new MessageButton()
        .setCustomId('change_name')
        .setLabel('تغيير اسم الرول')
        .setStyle('PRIMARY')
        .setEmoji('✏️'),
      new MessageButton()
        .setCustomId('add_member')
        .setLabel('إضافة عضو إلى الرول')
        .setStyle('SUCCESS')
        .setEmoji('➕'),
      new MessageButton()
        .setCustomId('change_color')
        .setLabel('تغيير لون الرول')
        .setStyle('SECONDARY')
        .setEmoji('🎨')
    );

    const myRoleMessage = await message.reply({ embeds: [embed], components: [row] });

    const filter = (interaction) => interaction.isButton() && interaction.user.id === member.id;
    const collector = myRoleMessage.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
      if (interaction.customId === 'change_name') {
        await interaction.reply({ content: '✏️ **يرجى إرسال الاسم الجديد للرول.**' });
        const filter = (m) => m.author.id === member.id;
        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
        const newName = collected.first().content;
        await role.setName(newName);
        return interaction.followUp({ content: `✔ **تم تغيير اسم الرول إلى ${newName}!**` });
      } else if (interaction.customId === 'add_member') {
        await interaction.reply({ content: '➕ **يرجى منشن العضو الذي تريد إضافته إلى الرول.**' });
        const filter = (m) => m.mentions.members.first() && m.author.id === member.id;
        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
        const newMember = collected.first().mentions.members.first();
        await newMember.roles.add(role);
        return interaction.followUp({ content: `✔ **تمت إضافة ${newMember.user.tag} إلى ${role.name} بنجاح!**` });
      } else if (interaction.customId === 'change_color') {
        await interaction.reply({ content: '🎨 **يرجى إرسال الهاش للون الجديد.**' });
        const filter = (m) => /^#([0-9A-F]{3}){1,2}$/i.test(m.content) && m.author.id === member.id;
        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
        const newColor = collected.first().content;
        await role.setColor(newColor);
        return interaction.followUp({ content: `✔ **تم تغيير لون الرول إلى ${newColor}!**` });
      }
    });

    collector.on('end', () => {
      myRoleMessage.edit({ components: [] });
    });
  }
};
