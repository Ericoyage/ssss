const Discord = require('discord.js');

module.exports = {
  name: "server-info",
  aliases: ["info"],
  description: "Displays server information.",
  usage: [""],
  botPermission: [""],
  authorPermissions: ["ADMINISTRATOR"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args) => {
    const server = message.guild;

    // Fetch server owner details
    const owner = await server.fetchOwner();

    // Gather server details
    const totalMembers = server.memberCount;
    const humans = server.members.cache.filter(member => !member.user.bot).size;
    const bots = totalMembers - humans;
    const roleCount = server.roles.cache.size;
    const textChannels = server.channels.cache.filter(channel => channel.type === Discord.ChannelType.GuildText).size;
    const voiceChannels = server.channels.cache.filter(channel => channel.type === Discord.ChannelType.GuildVoice).size;

    // Voice status details
    const voiceMembers = server.members.cache.filter(member => member.voice.channel).size;
    const voiceHumans = server.members.cache.filter(member => member.voice.channel && !member.user.bot).size;
    const voiceBots = voiceMembers - voiceHumans;

    // Boost level
    const boostLevel = server.premiumTier || "None";
    const boostCount = server.premiumSubscriptionCount || 0;

    // Create embed
    const embed = new Discord.EmbedBuilder()
      .setColor("#7289DA")
      .setTitle(`Server Info : ${server.name}`)
      .setThumbnail(server.iconURL({ dynamic: true }))
      .addFields(
        { name: "Owner", value: `<@${owner.id}> (${owner.id})`, inline: false },
        { name: "Create Time", value: `<t:${Math.floor(server.createdTimestamp / 1000)}:R>`, inline: false },
        { name: "All Info", value: `**All Members**: ${totalMembers}\n**Humans**: ${humans}\n**Bots**: ${bots}\n**Role Count**: ${roleCount}\n**Text Channels**: ${textChannels}\n**Voice Channels**: ${voiceChannels}`, inline: false },
        { name: "Voice Status", value: `**Voice**: ${voiceMembers}\n**Humans**: ${voiceHumans}\n**Bots**: ${voiceBots}`, inline: false },
        { name: "Boosts Info", value: `**Boosts Level**: ${boostLevel}\n**Boosts**: ${boostCount}`, inline: false }
      )
      .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

    // Send embed
    message.channel.send({ embeds: [embed] });
  }
};
