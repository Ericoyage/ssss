const Discord = require('discord.js');

module.exports = {
  name: "antibots",
  aliases: ["منع_البوتات", "بوت"],
  description: "عند دخول بوت الى السيرفر سيتم طرده.",
  botPermission: ["KICK_MEMBERS"],
  authorPermission: ["MANAGE_GUILD"],
  cooldowns: [],
  ownerOnly: false,
  state: false, // Default state: Off

  run: async (client, message, args) => {
    // Toggle command to switch the state of antibots protection
    if (args[0] === 'on') {
      this.state = true;
      message.reply('تم تفعيل حماية ضد البوتات!');
    } else if (args[0] === 'off') {
      this.state = false;
      message.reply('تم تعطيل حماية ضد البوتات.');
    } else {
      message.reply('استخدم `on` لتفعيل أو `off` لتعطيل حماية ضد البوتات.');
      return;
    }

    // عند انضمام عضو جديد للسيرفر
    client.on('guildMemberAdd', async (member) => {
      // إذا كانت الحماية مفعلّة
      if (this.state && member.user.bot) {
        try {
          // طرد البوت من السيرفر
          await member.kick();
          
          const embed = new Discord.MessageEmbed()
            .setColor('#ff0000')
            .setDescription(`❌ **تم طرد البوت**: ${member.user.tag}`);
          
          // إرسال رسالة تأكيدية إلى القناة
          const logChannel = member.guild.channels.cache.find(channel => channel.name === 'log-channel'); // تغيير اسم القناة حسب حاجتك
          if (logChannel) logChannel.send({ embeds: [embed] });

        } catch (error) {
          console.error('حدث خطأ عند طرد البوت:', error);
        }
      }
    });
  }
};
