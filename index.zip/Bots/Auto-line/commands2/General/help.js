const Discord = require('discord.js');
const { MessageEmbed, MessageActionRow, MessageSelectMenu } = require('discord.js');

module.exports = {
  name: "help",
  aliases: [""],
  description: "",
  usage: [""],
  botPermission: [""],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args) => {
    const embeds = [
      new MessageEmbed()
        .setColor(message.guild.me.displayHexColor)
        .setTitle('⚙️ **أوامر الأوتولاين**')
        .addFields(
          {
            name: `**set-line [رابط الخط]:**`,
            value: `__لتعيين خط جديد للسيرفر__`,
            inline: false,
          },
          {
            name: `**set-autoline [منشن/ID الروم]:**`,
            value: `__لتعيين روم أوتولاين جديد__`,
            inline: false,
          },
          {
            name: `**r-autoline [منشن/ID الروم]:**`,
            value: `__لإزالة روم الأوتولاين__`,
            inline: false,
          },
          {
            name: `**- || خط:**`,
            value: `__لإرجاع الخط__`,
            inline: false,
          },
          {
            name: `**set-allowline [منشن/ID الروم]:**`,
            value: `__لتعيين روم مسموح فيه الخط__`,
            inline: false,
          },
          {
            name: `**r-allowline [منشن/ID الروم]:**`,
            value: `__لإزالة روم مسموح فيه الخط__`,
            inline: false,
          },
        )
    ];

    const selectMenuOptions = embeds.map((embed, index) => ({
      label: embed.title,
      value: index.toString(),
      description: `لعرض أوامر ${embed.title}`,
      emoji: '⚙️',
    }));

    const selectMenu = new MessageSelectMenu()
      .setCustomId('help_select')
      .setPlaceholder('اختر صفحة...')
      .addOptions(selectMenuOptions);

    const actionRow = new MessageActionRow().addComponents(selectMenu);

    const initialEmbed = embeds[0];

    const helpMessage = await message.reply({
      embeds: [initialEmbed],
      components: [actionRow],
      allowedMentions: { repliedUser: false },
    });

    const filter = (interaction) =>
      interaction.isSelectMenu() && interaction.user.id === message.author.id;

    const collector = helpMessage.createMessageComponentCollector({
      filter,
      time: 60000,
    });

    collector.on('collect', (interaction) => {
      const selectedPageIndex = parseInt(interaction.values[0]);
      const selectedEmbed = embeds[selectedPageIndex];
      interaction.update({
        embeds: [selectedEmbed],
      });
    });

    collector.on('end', () => {
      helpMessage.edit({
        components: [],
      });
    });
  },
};
